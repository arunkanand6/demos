package com.capg.rockstarGames.controller;

import javax.validation.ConstraintViolationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import com.capg.rockstarGames.beans.Game;
import com.capg.rockstarGames.mapstruct.dto.GameDto;
import com.capg.rockstarGames.service.IRockstarService;

@CrossOrigin(origins = "http://localhost:9002")
@RestController
@RequestMapping("/api")
public class RockstarController {

	@Autowired
	private IRockstarService service;

	final Logger LOGGER = LoggerFactory.getLogger(this.getClass());
	
	@PostMapping("/add")
	public ResponseEntity<GameDto> addGame(@RequestBody Game game) {
		LOGGER.info("Add game controller initialized");
		GameDto gameDto = service.addGame(game);
		LOGGER.info("Add game controller executed");
		return new ResponseEntity<GameDto>(gameDto, HttpStatus.OK);
	}

	@GetMapping("/get/{id}")
	public ResponseEntity<GameDto> getGame(@PathVariable int id) {
		LOGGER.info("Get game controller initialized");
		GameDto gameDto = service.getGame(id);
		LOGGER.info("Get game controller executed");
		return new ResponseEntity<GameDto>(gameDto, HttpStatus.OK);
	}
	
	@ExceptionHandler(value = ConstraintViolationException.class)
	public ResponseEntity<Object> exceptionConstraintViolationException(ConstraintViolationException exception) {
		StringBuilder msg = new StringBuilder();
		exception.getConstraintViolations().forEach(i -> msg.append(i.getConstraintDescriptor().getMessageTemplate()));
		return new ResponseEntity<>(msg.toString(), HttpStatus.NOT_ACCEPTABLE);
	}

	@ExceptionHandler(value = NullPointerException.class)
	public ResponseEntity<Object> exceptionInvalidInputException(NullPointerException exception) {
		return new ResponseEntity<>(exception.getMessage(), HttpStatus.NOT_ACCEPTABLE);
	}
	
	@ExceptionHandler(value = MethodArgumentTypeMismatchException.class)
	public ResponseEntity<Object> exceptionInvalidInputException(MethodArgumentTypeMismatchException exception) {
		return new ResponseEntity<>("Please enter a valid id", HttpStatus.NOT_ACCEPTABLE);
	}
	
	
	
//	@GetMapping("/healthCheck")
//	public ResponseEntity<Map<String, String>> healthCheck() {
//		Map<String, String> map = new HashMap<>();
//		RestTemplate restTemplate = new RestTemplate();
//		ResponseEntity<GameDto> add = this.addGame(null);
//		ResponseEntity<GameDto> get = this.getGame(0);
//		add.getStatusCode();
////		String result = restTemplate.getForObject("localhost:9001/addGame", String.class,);
//	}

//	private String getStudentString()
//		{
//		    String uri = "http://localhost:8080/student";
//		    RestTemplate restTemplate = new RestTemplate();
//		    String result = restTemplate.getForObject(uri, String.class);
//		    return result; 
//		}

}
