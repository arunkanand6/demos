package com.capg.rockstarGames.service;

import com.capg.rockstarGames.beans.Game;
import com.capg.rockstarGames.mapstruct.dto.GameDto;

public interface IRockstarService {

	GameDto addGame(Game game);

	GameDto getGame(int id);

}
