package com.capg.rockstar1.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.capg.rockstar1.beans.Game;
import com.capg.rockstar1.dto.GameDto;

@RestController
@RefreshScope
@RequestMapping("/api")
public class ServerController {

	@PostMapping("/add")
	public GameDto addGame(@RequestBody Game game) {
		RestTemplate restTemplate = new RestTemplate();
		System.out.println(game);
		String addGameUrl = "http://localhost:9001/api/add";
		ResponseEntity<GameDto> response = restTemplate.postForEntity(addGameUrl, game, GameDto.class);
		return response.getBody();
	}

	@GetMapping("/get/{id}")
	public GameDto getGame(@PathVariable int id) {
		RestTemplate restTemplate = new RestTemplate();
		
		String getGameUrl = "http://localhost:9001/api/get/";
		ResponseEntity<GameDto> response = restTemplate.getForEntity(getGameUrl + id, GameDto.class);
		return response.getBody();
	}
	
//	@Value("${message:default hello}")
	public String message;
	
	@GetMapping("/message")
	public String getMessage() {
		return message;
	}
}
