package com.capg.rockstar1.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import com.capg.rockstar1.beans.Game;
import com.capg.rockstar1.dto.GameDto;


@FeignClient(url = "http://localhost:9001",name = "Client")
public interface ClientFeign {

	@PostMapping("/api/add")
	GameDto addGame(Game game);
	
//	@GetMapping("/get/{id}")
//	GameDto getGame(int id);
	
	
	@GetMapping("/api/get/{id}")
	GameDto getGame(@PathVariable("id") int id);
	
	
}